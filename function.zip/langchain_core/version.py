"""langchain-core version information and utilities."""

VERSION = "1.0.4"
